const swiper = new Swiper('.swiper', {
  speed: 400,
  spaceBetween: 100,

 




});